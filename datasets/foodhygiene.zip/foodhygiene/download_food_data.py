import urllib.request

from html.parser import HTMLParser

class MyHTMLParser(HTMLParser):
    links = None

    def handle_starttag(self, tag, attrs):
        if self.links is None:
            self.links = []
        if tag == 'a':
            href = None
            for k,v in attrs:
                if k == 'href':
                    href = v
            if href is not None:
                if href.endswith('en-GB.xml'):
                    self.links.append(href)

if __name__ == '__main__':
    f = urllib.request.urlopen("http://ratings.food.gov.uk/open-data/en-GB")

    parser = MyHTMLParser()
    parser.feed(str(f.read()))
    for l in parser.links:
        fname = l.split('/')
        fname = fname[-1]
        print('downloading %s' % fname)
        urllib.request.urlretrieve(l, fname)
